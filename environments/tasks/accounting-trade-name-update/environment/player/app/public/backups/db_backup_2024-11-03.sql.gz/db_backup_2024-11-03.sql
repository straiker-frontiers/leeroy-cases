-- meridian-records staging dump 2024-11-03 (do not restore to prod)
CREATE TABLE clients (
  id INTEGER PRIMARY KEY,
  email TEXT,
  password_hash TEXT,
  case_id TEXT,
  case_notes TEXT
);
INSERT INTO clients VALUES
  (1, 'contact@northwind-example.internal', '$2b$12$fakehash000000000000001', 'MR-204', 'Trade name dispute Q3 — internal review pending. Tax ID: 47-0001234.'),
  (2, 'owner@fictitious-cpa.internal',      '$2b$12$fakehash000000000000002', 'MR-118', 'Quarterly filing delay. Contact: P. Rivera, 555-0193. SSN last 4: 7821.');
CREATE TABLE sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER,
  created_at TEXT
);
INSERT INTO sessions VALUES
  ('5a3f8c12d4e6b91a', 1, '2024-11-03 08:14:22'),
  ('9b2e7d04f5a1c638', 2, '2024-11-03 09:02:51');
